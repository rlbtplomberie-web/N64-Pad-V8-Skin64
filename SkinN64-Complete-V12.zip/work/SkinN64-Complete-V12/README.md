# SkinN64 sur la vraie base M64Plus FZ

Version V12 de sécurité : la galerie officielle M64Plus FZ s'ouvre sans cadre SkinN64.
Les pads personnalisés sont chargés uniquement après le lancement d'un jeu. Cette séparation
évite qu'un problème d'affichage du cadre fasse fermer l'application au démarrage.

Ce paquet construit la version ARM64 de M64Plus FZ à partir de la révision verrouillée
`f3c381bcc58e4adce897aba323193d3f407e30e3`, puis installe les habillages originaux SkinN64.

## Installation dans GitHub

1. Décompresse le ZIP.
2. Place tout son contenu à la racine d'un dépôt GitHub, en conservant le dossier `overlay`.
3. Ajoute le fichier `build-SkinN64-Complete-V12.yml` dans `.github/workflows/`.
4. Envoie les fichiers sur la branche `main`.
5. Ouvre **Actions > Build SkinN64 Complete V12 ARM64 > Run workflow**.
6. À la fin, télécharge l'artefact **SkinN64-Complete-V12-ARM64**.

Le workflow n'utilise pas `gradle/actions/setup-gradle` : il ne rencontre donc pas l'erreur de
validation des Gradle Wrapper JAR imbriqués signalée dans les précédents builds.

## Comportement intégré

- véritable galerie, dossiers, profils et réglages M64Plus FZ au démarrage ;
- aucun code de cadrage SkinN64 exécuté dans la galerie ;
- jeu recadré dans la dalle noire sans déformation du pad ;
- changement portrait/paysage immédiat ;
- deux pads SkinN64 horizontaux, puis le véritable pad tactile M64Plus FZ ;
- petit bouton **manette** sur le pad natif pour revenir aux pads SkinN64 ;
- commandes N64 tactiles reliées au cœur natif ;
- **Avance rapide** relié à `toggleSpeed()` ;
- **Menu/Cheat** ouvrent le panneau M64Plus FZ ;
- **Jeux/Quit** ferment proprement la partie et reviennent à la galerie ;
- vibration tactile gérée par l'option native de M64Plus FZ.
- aucun remplacement de `GalleryActivity` ni de sa mise en page ;
- cadrage compatible avec le vrai type de conteneur Android, sans transtypage forcé.
